import React from 'react';
import TimelineWidget from './components/TimelineWidget';

function App() {
  return (
    <TimelineWidget />
  );
}

export default App;
